# 🔄 WORKFLOW MANDATE (The Crucial Base)

## 1. THE LAW OF ASSIGNMENT
*   **No Free-Roaming**: No task shall be executed without first being explicitly assigned to a `.agent/workflows/*.md` file.
*   **The Default**: If no specific workflow is required, the **Standard Task Lifecycle** (`standard-task-lifecycle.md`) applies automatically.

## 2. THE CYCLE
*   **Write**: Implementation must be preceded by or accompanied by test creation.
*   **Test**: Execution is NOT complete until the assigned workflow's testing phase passes.
*   **Review**: Code must be validated against Project Rules before closing the task.

## 3. THE BLOCKER
*   Any PR or Task marked "Done" without evidence of the Workflow's completion (Test Logs) is **INVALID**.
