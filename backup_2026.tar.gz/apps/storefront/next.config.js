/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ['@apex/ui-kit'],
};

module.exports = nextConfig;
