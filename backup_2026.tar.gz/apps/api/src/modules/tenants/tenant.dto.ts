export class TenantQuery {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    plan?: string;
}
